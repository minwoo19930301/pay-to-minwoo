
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// src/index.ts
import { Hono } from "hono";
import { z } from "zod";

// src/lib/config.ts
function getPublicBaseUrl(env) {
  const configured = env.PUBLIC_BASE_URL?.trim();
  return configured && configured.length > 0 ? configured : "http://127.0.0.1:8787";
}
function getAppName(env) {
  return env.APP_NAME?.trim() || "pay-to-minwoo";
}
function getPaymentMode(env) {
  return env.PAYMENT_MODE === "live" ? "live" : "mock";
}
function getStorageBackend(env) {
  return env.PAYMENT_STORAGE === "turso" ? "turso" : "memory";
}
function getMockWebhookSecret(env) {
  return env.MOCK_WEBHOOK_SECRET?.trim() || "pay-to-minwoo-dev-secret";
}
function getPayPalEnvironment(env) {
  return env.PAYPAL_ENV === "live" ? "live" : "sandbox";
}
function getPayPalCredentials(env) {
  const clientId = env.PAYPAL_CLIENT_ID?.trim();
  const clientSecret = env.PAYPAL_CLIENT_SECRET?.trim();
  if (!clientId || !clientSecret) {
    throw new Error("PAYPAL_CLIENT_ID and PAYPAL_CLIENT_SECRET are required for PayPal routes.");
  }
  return {
    environment: getPayPalEnvironment(env),
    clientId,
    clientSecret,
    webhookId: env.PAYPAL_WEBHOOK_ID?.trim() || void 0
  };
}

// src/lib/errors.ts
var AppError = class extends Error {
  code;
  status;
  details;
  constructor(code, message, status = 400, details) {
    super(message);
    this.name = "AppError";
    this.code = code;
    this.status = status;
    this.details = details;
  }
};
function asAppError(error) {
  if (error instanceof AppError) {
    return error;
  }
  if (error instanceof Error) {
    return new AppError("INTERNAL_ERROR", error.message, 500);
  }
  return new AppError("INTERNAL_ERROR", "Unknown error", 500);
}

// src/lib/domain.ts
var allowedAttemptTransitions = {
  authorize: ["created", "checkout_opened"],
  capture: ["authorized", "checkout_opened"],
  fail: ["created", "checkout_opened", "authorized"],
  refund: ["captured"],
  dispute: ["captured", "refunded"]
};
var actionTransitions = {
  authorize: {
    intentStatus: "processing",
    attemptStatus: "authorized"
  },
  capture: {
    intentStatus: "succeeded",
    attemptStatus: "captured"
  },
  fail: {
    intentStatus: "failed",
    attemptStatus: "failed"
  },
  refund: {
    intentStatus: "refunded",
    attemptStatus: "refunded"
  },
  dispute: {
    intentStatus: "disputed",
    attemptStatus: "disputed"
  }
};
var actionEventType = {
  authorize: "payment.authorized",
  capture: "payment.captured",
  fail: "payment.failed",
  refund: "payment.refunded",
  dispute: "payment.disputed"
};
function createEntityId(prefix) {
  return `${prefix}_${crypto.randomUUID().replace(/-/g, "").slice(0, 24)}`;
}
function normalizeCurrency(currency) {
  return currency.trim().toUpperCase();
}
function calculateMockFee(amount) {
  return Math.max(1, Math.round(amount * 0.05));
}
function assertPositiveAmount(amount) {
  if (!Number.isInteger(amount) || amount <= 0) {
    throw new AppError("INVALID_AMOUNT", "Amount must be a positive integer.", 400);
  }
}
function makeTransition(action, currentStatus) {
  const allowed = allowedAttemptTransitions[action];
  if (!allowed.includes(currentStatus)) {
    throw new AppError(
      "INVALID_STATE_TRANSITION",
      `Cannot ${action} an attempt in ${currentStatus} state.`,
      409,
      {
        action,
        currentStatus,
        allowedStates: allowed
      }
    );
  }
  const next = actionTransitions[action];
  return {
    ...next,
    eventType: actionEventType[action]
  };
}
function getTargetTransition(action) {
  return {
    ...actionTransitions[action],
    eventType: actionEventType[action]
  };
}
function toSortedSnapshot(snapshot) {
  const byCreatedAtDesc = (left, right) => {
    const leftTime = left.createdAt ?? left.receivedAt ?? "";
    const rightTime = right.createdAt ?? right.receivedAt ?? "";
    return rightTime.localeCompare(leftTime);
  };
  return {
    intents: [...snapshot.intents].sort(byCreatedAtDesc),
    attempts: [...snapshot.attempts].sort(byCreatedAtDesc),
    providerEvents: [...snapshot.providerEvents].sort(byCreatedAtDesc),
    auditLogs: [...snapshot.auditLogs].sort(byCreatedAtDesc),
    idempotencyRecords: [...snapshot.idempotencyRecords].sort(byCreatedAtDesc),
    settlements: [...snapshot.settlements].sort(byCreatedAtDesc),
    ledgerEntries: [...snapshot.ledgerEntries].sort(byCreatedAtDesc)
  };
}

// src/lib/mock-provider.ts
function createMockCheckoutSession(baseUrl, attemptId) {
  const checkoutUrl = new URL(`/demo/checkout/${attemptId}`, baseUrl);
  return {
    provider: "mock",
    providerPaymentId: createEntityId("mockpay"),
    checkoutUrl: checkoutUrl.toString()
  };
}
function makeMockEventPayload(type, attemptId) {
  return {
    eventId: createEntityId("evt"),
    type,
    attemptId,
    provider: "mock",
    happenedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
}
async function importWebhookKey(secret) {
  return crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(secret),
    {
      name: "HMAC",
      hash: "SHA-256"
    },
    false,
    ["sign"]
  );
}
function toHex(buffer) {
  return Array.from(new Uint8Array(buffer)).map((byte) => byte.toString(16).padStart(2, "0")).join("");
}
async function signMockWebhook(secret, payload) {
  const key = await importWebhookKey(secret);
  const signature = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(payload));
  return toHex(signature);
}
async function verifyMockWebhook(secret, payload, signature) {
  const expected = await signMockWebhook(secret, payload);
  return expected === signature;
}

// src/lib/paypal.ts
function buildPayPalWebhookHeaders(headers) {
  return {
    authAlgo: headers.get("paypal-auth-algo")?.trim() || "",
    certUrl: headers.get("paypal-cert-url")?.trim() || "",
    transmissionId: headers.get("paypal-transmission-id")?.trim() || "",
    transmissionSig: headers.get("paypal-transmission-sig")?.trim() || "",
    transmissionTime: headers.get("paypal-transmission-time")?.trim() || ""
  };
}
function getPayPalApprovalUrl(order) {
  const approve = order.links.find((link) => link.rel === "approve" || link.rel === "payer-action");
  if (!approve?.href) {
    throw new AppError("PAYPAL_APPROVAL_URL_MISSING", "PayPal order did not include an approval URL.", 502);
  }
  return approve.href;
}
function mapPayPalWebhookEventToDomainType(eventType) {
  switch (eventType) {
    case "CHECKOUT.ORDER.APPROVED":
      return "payment.authorized";
    case "PAYMENT.CAPTURE.COMPLETED":
      return "payment.captured";
    case "PAYMENT.CAPTURE.DENIED":
    case "CHECKOUT.PAYMENT-APPROVAL.REVERSED":
      return "payment.failed";
    case "PAYMENT.CAPTURE.REFUNDED":
    case "PAYMENT.CAPTURE.REVERSED":
      return "payment.refunded";
    case "CUSTOMER.DISPUTE.CREATED":
      return "payment.disputed";
    default:
      return void 0;
  }
}
function extractPayPalOrderId(payload) {
  const resource = asRecord(payload.resource);
  if (!resource) {
    return void 0;
  }
  if (typeof resource.id === "string" && String(payload.event_type) === "CHECKOUT.ORDER.APPROVED") {
    return resource.id;
  }
  const supplementaryData = asRecord(resource.supplementary_data);
  const relatedIds = asRecord(supplementaryData?.related_ids);
  return typeof relatedIds?.order_id === "string" ? relatedIds.order_id : void 0;
}
function extractPayPalAttemptId(payload) {
  const resource = asRecord(payload.resource);
  if (!resource) {
    return void 0;
  }
  const directCustomId = typeof resource.custom_id === "string" ? resource.custom_id : void 0;
  if (directCustomId) {
    return directCustomId;
  }
  const purchaseUnits = Array.isArray(resource.purchase_units) ? resource.purchase_units : [];
  const firstPurchaseUnit = asRecord(purchaseUnits[0]);
  return typeof firstPurchaseUnit?.custom_id === "string" ? firstPurchaseUnit.custom_id : void 0;
}
function asRecord(value) {
  return value && typeof value === "object" ? value : void 0;
}
function getBaseUrl(environment) {
  return environment === "live" ? "https://api-m.paypal.com" : "https://api-m.sandbox.paypal.com";
}
function isZeroDecimalCurrency(currency) {
  return (/* @__PURE__ */ new Set(["HUF", "JPY", "TWD", "KRW"])).has(currency.toUpperCase());
}
function toPayPalAmountValue(amount, currency) {
  if (isZeroDecimalCurrency(currency)) {
    return String(amount);
  }
  return `${amount}.00`;
}
async function getAccessToken(credentials) {
  const response = await fetch(`${getBaseUrl(credentials.environment)}/v1/oauth2/token`, {
    method: "POST",
    headers: {
      Authorization: `Basic ${btoa(`${credentials.clientId}:${credentials.clientSecret}`)}`,
      "Content-Type": "application/x-www-form-urlencoded"
    },
    body: "grant_type=client_credentials"
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || typeof payload.access_token !== "string") {
    throw new AppError("PAYPAL_OAUTH_FAILED", "Failed to obtain PayPal access token.", 502, {
      status: response.status,
      payload
    });
  }
  return payload.access_token;
}
async function createPayPalOrder(credentials, input) {
  const accessToken = await getAccessToken(credentials);
  const response = await fetch(`${getBaseUrl(credentials.environment)}/v2/checkout/orders`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json",
      Prefer: "return=representation",
      ...input.requestId ? { "PayPal-Request-Id": input.requestId } : {}
    },
    body: JSON.stringify({
      intent: "CAPTURE",
      purchase_units: [
        {
          reference_id: input.intentId,
          custom_id: input.attemptId,
          description: input.itemName,
          amount: {
            currency_code: input.currency,
            value: toPayPalAmountValue(input.amount, input.currency)
          }
        }
      ],
      ...input.returnUrl || input.cancelUrl ? {
        payment_source: {
          paypal: {
            experience_context: {
              ...input.returnUrl ? { return_url: input.returnUrl } : {},
              ...input.cancelUrl ? { cancel_url: input.cancelUrl } : {},
              user_action: "PAY_NOW"
            }
          }
        }
      } : {}
    })
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || typeof payload.id !== "string") {
    throw new AppError("PAYPAL_ORDER_CREATE_FAILED", "Failed to create PayPal order.", 502, {
      status: response.status,
      payload
    });
  }
  return payload;
}
async function capturePayPalOrder(credentials, orderId, requestId) {
  const accessToken = await getAccessToken(credentials);
  const response = await fetch(`${getBaseUrl(credentials.environment)}/v2/checkout/orders/${orderId}/capture`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json",
      Prefer: "return=representation",
      ...requestId ? { "PayPal-Request-Id": requestId } : {}
    }
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || typeof payload.id !== "string") {
    throw new AppError("PAYPAL_ORDER_CAPTURE_FAILED", "Failed to capture PayPal order.", 502, {
      status: response.status,
      payload
    });
  }
  return payload;
}
async function verifyPayPalWebhook(credentials, headers, webhookEvent) {
  if (!credentials.webhookId) {
    throw new AppError("PAYPAL_WEBHOOK_ID_MISSING", "PAYPAL_WEBHOOK_ID is required for webhook verification.", 500);
  }
  const accessToken = await getAccessToken(credentials);
  const response = await fetch(`${getBaseUrl(credentials.environment)}/v1/notifications/verify-webhook-signature`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      auth_algo: headers.authAlgo,
      cert_url: headers.certUrl,
      transmission_id: headers.transmissionId,
      transmission_sig: headers.transmissionSig,
      transmission_time: headers.transmissionTime,
      webhook_id: credentials.webhookId,
      webhook_event: webhookEvent
    })
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new AppError("PAYPAL_WEBHOOK_VERIFY_FAILED", "Failed to verify PayPal webhook signature.", 502, {
      status: response.status,
      payload
    });
  }
  return payload.verification_status === "SUCCESS";
}

// src/lib/pages.ts
import { html } from "hono/html";
function pretty(value) {
  return JSON.stringify(value, null, 2);
}
function renderHomePage(input) {
  return html`<!doctype html>
    <html lang="ko">
      <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>${input.appName}</title>
        <style>
          :root {
            color-scheme: light;
            --bg: #f3efe6;
            --paper: rgba(255, 251, 244, 0.88);
            --ink: #1c1712;
            --muted: #6c635d;
            --line: #d6c4b0;
            --primary: #0f5c52;
            --primary-strong: #0a4139;
            --accent: #ad4f2f;
            --danger: #8b2c2c;
          }
          * { box-sizing: border-box; }
          body {
            margin: 0;
            font-family: "Iowan Old Style", "Palatino Linotype", serif;
            color: var(--ink);
            background:
              radial-gradient(circle at top left, rgba(173,79,47,0.15), transparent 28%),
              radial-gradient(circle at bottom right, rgba(15,92,82,0.12), transparent 28%),
              var(--bg);
          }
          main {
            max-width: 1220px;
            margin: 0 auto;
            padding: 40px 18px 88px;
          }
          .hero {
            display: grid;
            gap: 18px;
            margin-bottom: 24px;
          }
          .eyebrow {
            font-size: 12px;
            letter-spacing: 0.18em;
            text-transform: uppercase;
            color: var(--muted);
          }
          h1 {
            margin: 0;
            font-size: clamp(42px, 8vw, 86px);
            line-height: 0.92;
            max-width: 960px;
          }
          .lede {
            max-width: 820px;
            margin: 0;
            color: var(--muted);
            font-size: 18px;
            line-height: 1.65;
          }
          .pill-row {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
          }
          .pill {
            border: 1px solid var(--line);
            border-radius: 999px;
            padding: 8px 12px;
            font-size: 13px;
            background: rgba(255,255,255,0.7);
          }
          .section-title {
            margin: 0 0 12px;
            font-size: 26px;
          }
          .grid {
            display: grid;
            gap: 18px;
          }
          .grid.cards {
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            margin-bottom: 24px;
          }
          .grid.workbench {
            grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
            margin-bottom: 24px;
          }
          .grid.snapshot {
            grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
          }
          .card {
            background: var(--paper);
            border: 1px solid var(--line);
            border-radius: 24px;
            padding: 22px;
            box-shadow: 0 12px 28px rgba(28,23,18,0.07);
          }
          .card h2, .card h3 {
            margin: 0 0 8px;
          }
          .card p, .card li {
            color: var(--muted);
            line-height: 1.55;
          }
          .card ul {
            margin: 10px 0 0;
            padding-left: 18px;
          }
          form {
            display: grid;
            gap: 12px;
          }
          label {
            display: grid;
            gap: 6px;
            font-size: 14px;
          }
          input, select, button, textarea {
            font: inherit;
          }
          input, select, textarea {
            width: 100%;
            border-radius: 14px;
            border: 1px solid var(--line);
            padding: 12px 14px;
            background: rgba(255,255,255,0.92);
          }
          textarea {
            min-height: 96px;
            resize: vertical;
          }
          .button-row {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
          }
          button, .link-button {
            border: 0;
            border-radius: 14px;
            padding: 13px 16px;
            cursor: pointer;
            color: #fff;
            background: var(--primary);
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
          }
          button.secondary, .link-button.secondary {
            background: var(--accent);
          }
          button.ghost {
            background: #fff;
            color: var(--ink);
            border: 1px solid var(--line);
          }
          button.danger {
            background: var(--danger);
          }
          pre {
            margin: 0;
            padding: 16px;
            border-radius: 18px;
            background: #181512;
            color: #f7f2ea;
            min-height: 180px;
            overflow: auto;
            font-size: 12px;
            line-height: 1.55;
          }
          code.inline {
            background: rgba(15,92,82,0.08);
            padding: 2px 6px;
            border-radius: 999px;
          }
          .muted {
            color: var(--muted);
            font-size: 14px;
          }
          @media (max-width: 720px) {
            main {
              padding-top: 28px;
            }
            .card {
              padding: 18px;
            }
            h1 {
              line-height: 0.98;
            }
          }
        </style>
      </head>
      <body>
        <main>
          <section class="hero">
            <span class="eyebrow">payment domain lab</span>
            <h1>Pay to Minwoo, but as a payment system laboratory.</h1>
            <p class="lede">
              실제 도네이션 연결 전 단계에서 결제 도메인을 분해해서 보는 화면입니다. 지금은 mock provider로만 동작하지만,
              intent, attempt, webhook event, audit log, idempotency를 모두 드러내고 있습니다.
            </p>
            <div class="pill-row">
              <span class="pill">mode: ${input.paymentMode}</span>
              <span class="pill">base URL: ${input.baseUrl}</span>
              <span class="pill">storage: ${input.storage} repository</span>
            </div>
          </section>

          <section>
            <h2 class="section-title">Implemented Domains</h2>
            <div class="grid cards">
              <article class="card">
                <h3>Donation Intent</h3>
                <p>후원자가 얼마를 어떤 통화로 누구에게 보내려는지 표현하는 의도입니다. 아직 돈이 움직인 상태는 아닙니다.</p>
              </article>
              <article class="card">
                <h3>Payment Attempt</h3>
                <p>실제 결제사에 나가는 1회 시도입니다. provider payment id, checkout URL, 상태 전이가 여기 묶입니다.</p>
              </article>
              <article class="card">
                <h3>Provider Event</h3>
                <p>웹훅 또는 시뮬레이션으로 들어오는 외부 사실입니다. 성공/실패 판단의 근거는 이벤트입니다.</p>
              </article>
              <article class="card">
                <h3>Audit Log</h3>
                <p>사용자 행동, 시스템 결정, 외부 이벤트 수신을 모두 남깁니다. 결제는 추적성이 없으면 운영이 무너집니다.</p>
              </article>
              <article class="card">
                <h3>Idempotency</h3>
                <p>같은 요청이 재전송되어도 중복 intent/attempt가 생기지 않도록 막는 키입니다.</p>
              </article>
              <article class="card">
                <h3>Settlement Record</h3>
                <p>결제 성공 뒤 아직 네 통장에 들어오기 전의 정산 대기/보류/지급 완료 상태를 표현합니다.</p>
              </article>
              <article class="card">
                <h3>Ledger Entry</h3>
                <p>gross, fee, refund, payout 같은 금액 변화를 누적 기록합니다. 이게 있어야 미정산 잔액이 보입니다.</p>
              </article>
            </div>
          </section>

          <section>
            <h2 class="section-title">Workbench</h2>
            <div class="grid workbench">
              <article class="card">
                <h3>1. Create Donation Intent</h3>
                <form id="intent-form">
                  <label>Item name<input name="itemName" value="Support Minwoo's experiments" required /></label>
                  <label>Amount<input name="amount" type="number" min="1" value="10000" required /></label>
                  <label>Currency
                    <select name="currency">
                      <option>KRW</option>
                      <option>USD</option>
                      <option>EUR</option>
                    </select>
                  </label>
                  <label>Region
                    <select name="region">
                      <option value="domestic">domestic</option>
                      <option value="international">international</option>
                    </select>
                  </label>
                  <label>Customer name<input name="customerName" value="Kim Minwoo Fan" required /></label>
                  <label>Customer email<input name="customerEmail" type="email" value="fan@example.com" required /></label>
                  <label>Note<textarea name="note">Thanks for the work. This is a mock donation.</textarea></label>
                  <label>Idempotency key<input name="idempotencyKey" placeholder="leave empty to auto-generate" /></label>
                  <button type="submit">Create intent</button>
                </form>
              </article>

              <article class="card">
                <h3>2. Start Mock Checkout</h3>
                <form id="checkout-form">
                  <label>Intent ID<input name="intentId" id="intent-id-input" placeholder="intent_xxx" required /></label>
                  <label>Checkout idempotency key<input name="idempotencyKey" placeholder="optional" /></label>
                  <button type="submit" class="secondary">Create payment attempt</button>
                </form>
                <p class="muted">
                  생성된 attempt는 mock checkout 페이지로 이동할 수 있습니다. 거기서 authorize, capture, fail, refund, dispute를 하나씩 눌러볼 수 있습니다.
                </p>
                <div class="button-row">
                  <a id="checkout-link" class="link-button ghost" href="#">Latest checkout pending</a>
                </div>
              </article>

              <article class="card">
                <h3>3. Observe The System</h3>
                <div class="button-row">
                  <button id="refresh-button" type="button" class="ghost">Refresh snapshot</button>
                  <button id="reset-button" type="button" class="danger">Reset in-memory lab</button>
                </div>
                <p class="muted">
                  이 mock에서는 메모리 저장소를 씁니다. 서버 재시작 또는 배포 환경 변경 시 상태는 초기화됩니다. 실전에서는 이 레이어만 DB로 바꾸면 됩니다.
                </p>
                <p class="muted">
                  별도 webhook endpoint도 구현되어 있습니다. 실제 provider를 붙일 때는 서명 검증 후 같은 도메인 서비스로 들어오게 됩니다.
                </p>
                <p class="muted">
                  이제는 결제 성공만이 아니라 정산 대기, 정산 완료, outstanding balance까지 함께 추적합니다.
                </p>
              </article>
            </div>
          </section>

          <section>
            <h2 class="section-title">Latest API Result</h2>
            <article class="card" style="margin-bottom:24px;">
              <pre id="result">${pretty(input.snapshot)}</pre>
            </article>
          </section>

          <section>
            <h2 class="section-title">Snapshot</h2>
            <div class="grid snapshot">
              <article class="card"><h3>Intents</h3><pre id="snapshot-intents">${pretty(input.snapshot.intents)}</pre></article>
              <article class="card"><h3>Attempts</h3><pre id="snapshot-attempts">${pretty(input.snapshot.attempts)}</pre></article>
              <article class="card"><h3>Provider Events</h3><pre id="snapshot-events">${pretty(input.snapshot.providerEvents)}</pre></article>
              <article class="card"><h3>Audit Logs</h3><pre id="snapshot-audits">${pretty(input.snapshot.auditLogs)}</pre></article>
              <article class="card"><h3>Idempotency</h3><pre id="snapshot-idempotency">${pretty(input.snapshot.idempotencyRecords)}</pre></article>
              <article class="card"><h3>Settlements</h3><pre id="snapshot-settlements">${pretty(input.snapshot.settlements)}</pre></article>
              <article class="card"><h3>Ledger</h3><pre id="snapshot-ledger">${pretty(input.snapshot.ledgerEntries)}</pre></article>
            </div>
          </section>
        </main>
        <script>
          const resultEl = document.getElementById("result");
          const intentIdInput = document.getElementById("intent-id-input");
          const checkoutLink = document.getElementById("checkout-link");

          async function api(path, options) {
            const response = await fetch(path, {
              headers: { "content-type": "application/json" },
              ...options
            });
            const payload = await response.json();

            if (!response.ok) {
              throw new Error(JSON.stringify(payload, null, 2));
            }

            return payload;
          }

          function renderSnapshot(snapshot) {
            document.getElementById("snapshot-intents").textContent = JSON.stringify(snapshot.intents, null, 2);
            document.getElementById("snapshot-attempts").textContent = JSON.stringify(snapshot.attempts, null, 2);
            document.getElementById("snapshot-events").textContent = JSON.stringify(snapshot.providerEvents, null, 2);
            document.getElementById("snapshot-audits").textContent = JSON.stringify(snapshot.auditLogs, null, 2);
            document.getElementById("snapshot-idempotency").textContent = JSON.stringify(snapshot.idempotencyRecords, null, 2);
            document.getElementById("snapshot-settlements").textContent = JSON.stringify(snapshot.settlements, null, 2);
            document.getElementById("snapshot-ledger").textContent = JSON.stringify(snapshot.ledgerEntries, null, 2);
          }

          async function refreshSnapshot() {
            const payload = await api("/api/lab/snapshot");
            renderSnapshot(payload.snapshot);
            return payload.snapshot;
          }

          document.getElementById("intent-form").addEventListener("submit", async (event) => {
            event.preventDefault();
            const formData = Object.fromEntries(new FormData(event.currentTarget).entries());
            formData.amount = Number(formData.amount);

            try {
              const payload = await api("/api/lab/intents", {
                method: "POST",
                body: JSON.stringify(formData)
              });
              resultEl.textContent = JSON.stringify(payload, null, 2);
              intentIdInput.value = payload.intent.id;
              await refreshSnapshot();
            } catch (error) {
              resultEl.textContent = error instanceof Error ? error.message : String(error);
            }
          });

          document.getElementById("checkout-form").addEventListener("submit", async (event) => {
            event.preventDefault();
            const formData = Object.fromEntries(new FormData(event.currentTarget).entries());
            const intentId = String(formData.intentId || "").trim();

            try {
              const payload = await api("/api/lab/intents/" + intentId + "/checkout", {
                method: "POST",
                body: JSON.stringify({ idempotencyKey: formData.idempotencyKey || undefined })
              });
              resultEl.textContent = JSON.stringify(payload, null, 2);
              checkoutLink.href = payload.attempt.checkoutUrl;
              checkoutLink.textContent = "Open " + payload.attempt.id;
              await refreshSnapshot();
            } catch (error) {
              resultEl.textContent = error instanceof Error ? error.message : String(error);
            }
          });

          document.getElementById("refresh-button").addEventListener("click", async () => {
            try {
              const snapshot = await refreshSnapshot();
              resultEl.textContent = JSON.stringify({ ok: true, snapshot }, null, 2);
            } catch (error) {
              resultEl.textContent = error instanceof Error ? error.message : String(error);
            }
          });

          document.getElementById("reset-button").addEventListener("click", async () => {
            try {
              const payload = await api("/api/lab/reset", { method: "POST", body: JSON.stringify({}) });
              resultEl.textContent = JSON.stringify(payload, null, 2);
              checkoutLink.href = "#";
              checkoutLink.textContent = "Latest checkout pending";
              await refreshSnapshot();
            } catch (error) {
              resultEl.textContent = error instanceof Error ? error.message : String(error);
            }
          });
        </script>
      </body>
    </html>`;
}
function renderCheckoutPage(input) {
  return html`<!doctype html>
    <html lang="ko">
      <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>Mock Checkout ${input.attemptId}</title>
        <style>
          :root {
            color-scheme: dark;
            --bg: #12100d;
            --panel: #1c1814;
            --ink: #f5efe6;
            --muted: #b9ac9d;
            --line: #3a3129;
            --primary: #ad4f2f;
            --primary-strong: #8b3c22;
            --secondary: #0f5c52;
          }
          * { box-sizing: border-box; }
          body {
            margin: 0;
            min-height: 100vh;
            font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
            background:
              radial-gradient(circle at top left, rgba(173,79,47,0.18), transparent 30%),
              radial-gradient(circle at bottom right, rgba(15,92,82,0.2), transparent 30%),
              var(--bg);
            color: var(--ink);
          }
          main {
            max-width: 1120px;
            margin: 0 auto;
            padding: 32px 16px 72px;
          }
          h1 {
            margin: 0 0 10px;
            font-size: clamp(34px, 7vw, 64px);
          }
          .lede {
            color: var(--muted);
            line-height: 1.7;
            margin: 0 0 18px;
            max-width: 860px;
          }
          .grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 16px;
            margin-bottom: 18px;
          }
          .card {
            background: rgba(28,24,20,0.92);
            border: 1px solid var(--line);
            border-radius: 22px;
            padding: 20px;
          }
          .button-row {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-bottom: 14px;
          }
          button, a {
            font: inherit;
          }
          button, .link {
            border: 0;
            border-radius: 14px;
            padding: 12px 14px;
            text-decoration: none;
            color: white;
            cursor: pointer;
          }
          button {
            background: var(--secondary);
          }
          button[data-action="capture"] {
            background: var(--primary);
          }
          button[data-action="fail"], button[data-action="dispute"] {
            background: #7a2d2d;
          }
          button[data-action="refund"] {
            background: #725015;
          }
          .link {
            display: inline-flex;
            background: transparent;
            border: 1px solid var(--line);
            color: var(--ink);
          }
          pre {
            margin: 0;
            padding: 14px;
            border-radius: 16px;
            background: #0c0b09;
            border: 1px solid #24201a;
            color: #efe5d8;
            overflow: auto;
            min-height: 200px;
            white-space: pre-wrap;
            word-break: break-word;
          }
          .muted {
            color: var(--muted);
          }
        </style>
      </head>
      <body>
        <main>
          <h1>Mock Checkout</h1>
          <p class="lede">
            이 페이지는 실제 결제사의 checkout을 흉내냅니다. 버튼을 누를 때마다 provider event가 생성되고,
            그 이벤트가 attempt와 intent 상태를 바꿉니다.
          </p>

          <div class="button-row">
            <button data-action="authorize">Authorize</button>
            <button data-action="capture">Capture</button>
            <button data-action="fail">Fail</button>
            <button data-action="refund">Refund</button>
            <button data-action="dispute">Dispute</button>
            <button id="payout-button">Mark payout</button>
            <button id="refresh-button">Refresh</button>
            <a class="link" href="/">Back to lab</a>
          </div>

          <div class="grid">
            <article class="card">
              <h2>Latest Result</h2>
              <pre id="result">${pretty(input.detail)}</pre>
            </article>
            <article class="card">
              <h2>Attempt</h2>
              <pre id="attempt-json">${pretty(input.detail.attempt)}</pre>
            </article>
            <article class="card">
              <h2>Intent</h2>
              <pre id="intent-json">${pretty(input.detail.intent)}</pre>
            </article>
            <article class="card">
              <h2>Settlement</h2>
              <pre id="settlements-json">${pretty(input.detail.settlements)}</pre>
            </article>
            <article class="card">
              <h2>Ledger</h2>
              <pre id="ledger-json">${pretty(input.detail.ledgerEntries)}</pre>
            </article>
            <article class="card">
              <h2>Outstanding Balance</h2>
              <pre id="balance-json">${pretty(input.detail.payableBalance)}</pre>
            </article>
            <article class="card">
              <h2>Provider Events</h2>
              <pre id="events-json">${pretty(input.detail.providerEvents)}</pre>
            </article>
            <article class="card">
              <h2>Audit Logs</h2>
              <pre id="logs-json">${pretty(input.detail.auditLogs)}</pre>
            </article>
          </div>
        </main>
        <script>
          const attemptId = ${JSON.stringify(input.attemptId)};
          const resultEl = document.getElementById("result");

          async function api(path, options) {
            const response = await fetch(path, {
              headers: { "content-type": "application/json" },
              ...options
            });
            const payload = await response.json();

            if (!response.ok) {
              throw new Error(JSON.stringify(payload, null, 2));
            }

            return payload;
          }

          function render(detail) {
            document.getElementById("attempt-json").textContent = JSON.stringify(detail.attempt, null, 2);
            document.getElementById("intent-json").textContent = JSON.stringify(detail.intent, null, 2);
            document.getElementById("settlements-json").textContent = JSON.stringify(detail.settlements, null, 2);
            document.getElementById("ledger-json").textContent = JSON.stringify(detail.ledgerEntries, null, 2);
            document.getElementById("balance-json").textContent = JSON.stringify(detail.payableBalance, null, 2);
            document.getElementById("events-json").textContent = JSON.stringify(detail.providerEvents, null, 2);
            document.getElementById("logs-json").textContent = JSON.stringify(detail.auditLogs, null, 2);
          }

          async function refresh() {
            const payload = await api("/api/lab/attempts/" + attemptId);
            render(payload);
            return payload;
          }

          document.querySelectorAll("button[data-action]").forEach((button) => {
            button.addEventListener("click", async () => {
              const action = button.dataset.action;

              try {
                const payload = await api("/api/lab/attempts/" + attemptId + "/actions/" + action, {
                  method: "POST",
                  body: JSON.stringify({})
                });
                resultEl.textContent = JSON.stringify(payload, null, 2);
                await refresh();
              } catch (error) {
                resultEl.textContent = error instanceof Error ? error.message : String(error);
              }
            });
          });

          document.getElementById("payout-button").addEventListener("click", async () => {
            try {
              const detail = await refresh();
              const settlement = Array.isArray(detail.settlements)
                ? detail.settlements.find((item) => item.status === "pending_payout")
                : undefined;

              if (!settlement) {
                throw new Error("No settlement is pending payout.");
              }

              const payload = await api("/api/lab/settlements/" + settlement.id + "/actions/payout", {
                method: "POST",
                body: JSON.stringify({})
              });
              resultEl.textContent = JSON.stringify(payload, null, 2);
              await refresh();
            } catch (error) {
              resultEl.textContent = error instanceof Error ? error.message : String(error);
            }
          });

          document.getElementById("refresh-button").addEventListener("click", async () => {
            try {
              const payload = await refresh();
              resultEl.textContent = JSON.stringify(payload, null, 2);
            } catch (error) {
              resultEl.textContent = error instanceof Error ? error.message : String(error);
            }
          });
        </script>
      </body>
    </html>`;
}

// src/lib/payment-lab-service.ts
function now() {
  return (/* @__PURE__ */ new Date()).toISOString();
}
function createIdempotencyKey() {
  return createEntityId("idem");
}
var PaymentLabService = class {
  constructor(repository, baseUrl) {
    this.repository = repository;
    this.baseUrl = baseUrl;
  }
  async getSnapshot() {
    return this.repository.getSnapshot();
  }
  async reset() {
    await this.repository.reset();
    return { ok: true };
  }
  async getIntent(intentId) {
    return this.requireIntent(intentId);
  }
  async getSettlement(settlementId) {
    return this.requireSettlement(settlementId);
  }
  async getAttempt(attemptId) {
    const attempt = await this.requireAttempt(attemptId);
    const intent = await this.requireIntent(attempt.intentId);
    const settlements = await this.repository.listSettlementsByAttempt(attemptId);
    const ledgerEntries = await this.repository.listLedgerEntriesByAttempt(attemptId);
    return {
      intent,
      attempt,
      settlements,
      ledgerEntries,
      payableBalance: this.computeOutstandingBalance(ledgerEntries),
      providerEvents: await this.repository.listEventsByAttempt(attemptId),
      auditLogs: await this.repository.listAuditLogsForAttempt(attemptId, intent.id)
    };
  }
  async createIntent(input) {
    assertPositiveAmount(input.amount);
    const idempotencyKey = input.idempotencyKey?.trim() || createIdempotencyKey();
    const scope = "intent:create";
    const replayed = await this.replayByIdempotency(scope, idempotencyKey, "intent");
    if (replayed) {
      return {
        intent: replayed,
        replayed: true
      };
    }
    const timestamp = now();
    const intent = {
      id: createEntityId("intent"),
      idempotencyKey,
      itemName: input.itemName.trim(),
      region: input.region,
      money: {
        amount: input.amount,
        currency: normalizeCurrency(input.currency)
      },
      donor: {
        name: input.customerName.trim(),
        email: input.customerEmail.trim().toLowerCase(),
        note: input.note?.trim() || void 0
      },
      status: "created",
      createdAt: timestamp,
      updatedAt: timestamp
    };
    await this.repository.saveIntent(intent);
    await this.repository.saveIdempotency(this.createIdempotencyRecord(scope, idempotencyKey, "intent", intent.id, timestamp));
    await this.writeAudit("intent", intent.id, "intent.created", "user", "Donation intent created.", {
      amount: intent.money.amount,
      currency: intent.money.currency,
      region: intent.region
    }, timestamp);
    return {
      intent,
      replayed: false
    };
  }
  async startCheckout(intentId, idempotencyKey) {
    const intent = await this.requireIntent(intentId);
    this.assertIntentAllowsCheckout(intent.status);
    const resolvedKey = idempotencyKey?.trim() || createIdempotencyKey();
    const scope = `checkout:start:mock:${intentId}`;
    const replayed = await this.replayByIdempotency(scope, resolvedKey, "attempt");
    if (replayed) {
      const replayedIntent = await this.requireIntent(replayed.intentId);
      const replayedEvent = replayed.lastEventId ? (await this.repository.listEventsByAttempt(replayed.id)).find((event2) => event2.id === replayed.lastEventId) : void 0;
      return {
        intent: replayedIntent,
        attempt: replayed,
        event: replayedEvent,
        replayed: true
      };
    }
    const timestamp = now();
    const session = createMockCheckoutSession(this.baseUrl, createEntityId("attempt"));
    const attempt = {
      id: session.checkoutUrl.split("/").pop() || createEntityId("attempt"),
      intentId: intent.id,
      provider: session.provider,
      providerPaymentId: session.providerPaymentId,
      status: "checkout_opened",
      checkoutUrl: session.checkoutUrl,
      createdAt: timestamp,
      updatedAt: timestamp
    };
    const event = this.createProviderEvent(attempt, intent.id, "checkout.opened", "simulation", true, timestamp, {
      ...makeMockEventPayload("checkout.opened", attempt.id),
      checkoutUrl: attempt.checkoutUrl
    });
    const updatedIntent = {
      ...intent,
      status: "checkout_ready",
      activeAttemptId: attempt.id,
      updatedAt: timestamp
    };
    const updatedAttempt = {
      ...attempt,
      lastEventId: event.id
    };
    await this.repository.saveAttempt(updatedAttempt);
    await this.repository.saveProviderEvent(event);
    await this.repository.saveIntent(updatedIntent);
    await this.repository.saveIdempotency(this.createIdempotencyRecord(scope, resolvedKey, "attempt", updatedAttempt.id, timestamp));
    await this.writeAudit("attempt", updatedAttempt.id, "attempt.created", "system", "Mock payment attempt created.", {
      intentId,
      providerPaymentId: updatedAttempt.providerPaymentId
    }, timestamp);
    await this.writeAudit("provider_event", event.id, event.type, "provider", "Checkout session opened by mock provider.", {
      attemptId: updatedAttempt.id,
      intentId
    }, timestamp);
    return {
      intent: updatedIntent,
      attempt: updatedAttempt,
      event,
      replayed: false
    };
  }
  async startExternalCheckout(input) {
    const intent = await this.requireIntent(input.intentId);
    this.assertIntentAllowsCheckout(intent.status);
    const resolvedKey = input.idempotencyKey?.trim() || createIdempotencyKey();
    const scope = `checkout:start:${input.provider}:${input.intentId}`;
    const replayed = await this.replayByIdempotency(scope, resolvedKey, "attempt");
    if (replayed) {
      const replayedIntent = await this.requireIntent(replayed.intentId);
      const replayedEvent = replayed.lastEventId ? (await this.repository.listEventsByAttempt(replayed.id)).find((event2) => event2.id === replayed.lastEventId) : void 0;
      return {
        intent: replayedIntent,
        attempt: replayed,
        event: replayedEvent,
        replayed: true
      };
    }
    const timestamp = now();
    const attempt = {
      id: input.attemptId ?? createEntityId("attempt"),
      intentId: intent.id,
      provider: input.provider,
      providerPaymentId: input.providerPaymentId,
      status: "checkout_opened",
      checkoutUrl: input.checkoutUrl,
      createdAt: timestamp,
      updatedAt: timestamp
    };
    const event = this.createProviderEvent(
      attempt,
      intent.id,
      "checkout.opened",
      input.source ?? "api",
      input.signatureVerified ?? true,
      timestamp,
      input.payload
    );
    const updatedIntent = {
      ...intent,
      status: "checkout_ready",
      activeAttemptId: attempt.id,
      updatedAt: timestamp
    };
    const updatedAttempt = {
      ...attempt,
      lastEventId: event.id
    };
    await this.repository.saveAttempt(updatedAttempt);
    await this.repository.saveProviderEvent(event);
    await this.repository.saveIntent(updatedIntent);
    await this.repository.saveIdempotency(this.createIdempotencyRecord(scope, resolvedKey, "attempt", updatedAttempt.id, timestamp));
    await this.writeAudit("attempt", updatedAttempt.id, "attempt.created", "system", `${input.provider} payment attempt created.`, {
      intentId: input.intentId,
      provider: input.provider,
      providerPaymentId: updatedAttempt.providerPaymentId
    }, timestamp);
    await this.writeAudit("provider_event", event.id, event.type, "provider", `Checkout session opened by ${input.provider}.`, {
      attemptId: updatedAttempt.id,
      intentId: input.intentId,
      provider: input.provider
    }, timestamp);
    return {
      intent: updatedIntent,
      attempt: updatedAttempt,
      event,
      replayed: false
    };
  }
  async applyAction(attemptId, action, source = "simulation", options) {
    const attempt = await this.requireAttempt(attemptId);
    const intent = await this.requireIntent(attempt.intentId);
    const targetTransition = getTargetTransition(action);
    const timestamp = now();
    const eventPayload = options?.payload ?? makeMockEventPayload(targetTransition.eventType, attemptId);
    const existingProviderEventId = options?.providerEventId ?? this.extractProviderEventId(eventPayload);
    if (existingProviderEventId) {
      const duplicateEvent = await this.findProviderEventByExternalId(attemptId, existingProviderEventId);
      if (duplicateEvent) {
        return {
          intent,
          attempt,
          event: duplicateEvent,
          settlement: await this.repository.findSettlementByAttempt(attempt.id),
          ledgerEntries: await this.repository.listLedgerEntriesByAttempt(attempt.id),
          replayed: true
        };
      }
    }
    if (attempt.status === targetTransition.attemptStatus) {
      const repeatedEvent = this.createProviderEvent(
        attempt,
        intent.id,
        targetTransition.eventType,
        source,
        options?.signatureVerified ?? source !== "simulation",
        timestamp,
        eventPayload
      );
      const updatedAttempt2 = {
        ...attempt,
        lastEventId: repeatedEvent.id,
        updatedAt: timestamp
      };
      await this.repository.saveAttempt(updatedAttempt2);
      await this.repository.saveProviderEvent(repeatedEvent);
      await this.writeAudit(
        "attempt",
        updatedAttempt2.id,
        `attempt.${action}.replayed`,
        this.actorFromSource(source),
        `Repeated ${action} event accepted without state mutation.`,
        {
          currentStatus: attempt.status,
          provider: attempt.provider,
          externalEventId: existingProviderEventId
        },
        timestamp
      );
      return {
        intent,
        attempt: updatedAttempt2,
        event: repeatedEvent,
        settlement: await this.repository.findSettlementByAttempt(updatedAttempt2.id),
        ledgerEntries: await this.repository.listLedgerEntriesByAttempt(updatedAttempt2.id),
        replayed: true
      };
    }
    const transition = makeTransition(action, attempt.status);
    const updatedAttempt = {
      ...attempt,
      status: transition.attemptStatus,
      updatedAt: timestamp
    };
    const updatedIntent = {
      ...intent,
      status: transition.intentStatus,
      activeAttemptId: attempt.id,
      updatedAt: timestamp
    };
    const event = this.createProviderEvent(
      updatedAttempt,
      updatedIntent.id,
      transition.eventType,
      source,
      options?.signatureVerified ?? source !== "simulation",
      timestamp,
      eventPayload
    );
    updatedAttempt.lastEventId = event.id;
    await this.repository.saveAttempt(updatedAttempt);
    await this.repository.saveIntent(updatedIntent);
    await this.repository.saveProviderEvent(event);
    const financials = await this.applyFinancialSideEffects(updatedIntent, updatedAttempt, action, timestamp);
    await this.writeAudit(
      "attempt",
      updatedAttempt.id,
      `attempt.${action}`,
      this.actorFromSource(source),
      `${attempt.provider} action ${action} applied to payment attempt.`,
      {
        fromStatus: attempt.status,
        toStatus: updatedAttempt.status,
        eventType: transition.eventType,
        provider: attempt.provider
      },
      timestamp
    );
    await this.writeAudit(
      "intent",
      updatedIntent.id,
      `intent.${updatedIntent.status}`,
      source === "webhook" ? "provider" : "system",
      `Donation intent moved to ${updatedIntent.status}.`,
      {
        attemptId,
        previousStatus: intent.status,
        nextStatus: updatedIntent.status
      },
      timestamp
    );
    await this.writeAudit(
      "provider_event",
      event.id,
      event.type,
      "provider",
      `Provider event ${event.type} ingested.`,
      {
        attemptId,
        intentId: updatedIntent.id,
        source: event.source,
        provider: event.provider
      },
      timestamp
    );
    return {
      intent: updatedIntent,
      attempt: updatedAttempt,
      event,
      ...financials
    };
  }
  async markSettlementPaidOut(settlementId) {
    const settlement = await this.requireSettlement(settlementId);
    if (settlement.status !== "pending_payout") {
      throw new AppError(
        "SETTLEMENT_NOT_PAYABLE",
        `Settlement ${settlement.id} is ${settlement.status}, not pending payout.`,
        409
      );
    }
    const timestamp = now();
    const updatedSettlement = {
      ...settlement,
      status: "paid_out",
      payoutReference: createEntityId("payout"),
      paidOutAt: timestamp,
      updatedAt: timestamp
    };
    const payoutEntry = await this.writeLedgerEntry({
      attemptId: settlement.attemptId,
      intentId: settlement.intentId,
      settlementId: settlement.id,
      type: "payout.completed",
      amount: settlement.netAmount,
      currency: settlement.currency,
      direction: "debit",
      createdAt: timestamp,
      metadata: {
        payoutReference: updatedSettlement.payoutReference
      }
    });
    await this.repository.saveSettlement(updatedSettlement);
    await this.writeAudit(
      "attempt",
      settlement.attemptId,
      "settlement.paid_out",
      "system",
      "Settlement marked as paid out to bank account.",
      {
        settlementId: settlement.id,
        payoutReference: updatedSettlement.payoutReference,
        netAmount: settlement.netAmount
      },
      timestamp
    );
    return {
      settlement: updatedSettlement,
      ledgerEntry: payoutEntry
    };
  }
  async ingestWebhook(payload) {
    const action = this.actionFromEventType(payload.type);
    return this.applyAction(payload.attemptId, action, "webhook");
  }
  async ingestProviderEvent(input) {
    const action = this.actionFromEventType(input.type);
    return this.applyAction(input.attemptId, action, input.source, {
      payload: input.payload,
      signatureVerified: input.signatureVerified,
      providerEventId: input.providerEventId
    });
  }
  async findAttemptByProviderPaymentId(provider, providerPaymentId) {
    const attempt = await this.repository.findAttemptByProviderPaymentId(provider, providerPaymentId);
    if (!attempt) {
      throw new AppError(
        "ATTEMPT_NOT_FOUND",
        `Payment attempt for ${provider}:${providerPaymentId} was not found.`,
        404
      );
    }
    return attempt;
  }
  actionFromEventType(type) {
    switch (type) {
      case "payment.authorized":
        return "authorize";
      case "payment.captured":
        return "capture";
      case "payment.failed":
        return "fail";
      case "payment.refunded":
        return "refund";
      case "payment.disputed":
        return "dispute";
      case "checkout.opened":
        throw new AppError(
          "INVALID_WEBHOOK_EVENT",
          "checkout.opened is produced internally when checkout is created.",
          400
        );
      default:
        throw new AppError("INVALID_WEBHOOK_EVENT", `Unsupported provider event: ${type}`, 400);
    }
  }
  async applyFinancialSideEffects(intent, attempt, action, timestamp) {
    switch (action) {
      case "capture": {
        const settlement = await this.createSettlementForCapture(intent, attempt, timestamp);
        const chargeEntry = await this.writeLedgerEntry({
          attemptId: attempt.id,
          intentId: intent.id,
          settlementId: settlement.id,
          type: "charge.captured",
          amount: settlement.grossAmount,
          currency: settlement.currency,
          direction: "credit",
          createdAt: timestamp,
          metadata: {
            providerPaymentId: attempt.providerPaymentId
          }
        });
        const feeEntry = await this.writeLedgerEntry({
          attemptId: attempt.id,
          intentId: intent.id,
          settlementId: settlement.id,
          type: "fee.assessed",
          amount: settlement.feeAmount,
          currency: settlement.currency,
          direction: "debit",
          createdAt: timestamp,
          metadata: {
            feeRate: "5%"
          }
        });
        await this.writeAudit(
          "attempt",
          attempt.id,
          "settlement.pending_payout",
          "system",
          "Settlement created and waiting for payout.",
          {
            settlementId: settlement.id,
            grossAmount: settlement.grossAmount,
            feeAmount: settlement.feeAmount,
            netAmount: settlement.netAmount
          },
          timestamp
        );
        return {
          settlement,
          ledgerEntries: [chargeEntry, feeEntry]
        };
      }
      case "refund": {
        const settlement = await this.requireOpenSettlementForAttempt(attempt.id, ["pending_payout", "blocked"]);
        const updatedSettlement = await this.updateSettlementStatus(settlement, "canceled", timestamp);
        const refundEntry = await this.writeLedgerEntry({
          attemptId: attempt.id,
          intentId: intent.id,
          settlementId: settlement.id,
          type: "refund.issued",
          amount: settlement.grossAmount,
          currency: settlement.currency,
          direction: "debit",
          createdAt: timestamp,
          metadata: {
            reason: "mock refund"
          }
        });
        const feeReverseEntry = await this.writeLedgerEntry({
          attemptId: attempt.id,
          intentId: intent.id,
          settlementId: settlement.id,
          type: "fee.reversed",
          amount: settlement.feeAmount,
          currency: settlement.currency,
          direction: "credit",
          createdAt: timestamp,
          metadata: {
            reason: "mock fee reversal"
          }
        });
        await this.writeAudit(
          "attempt",
          attempt.id,
          "settlement.canceled",
          "system",
          "Settlement canceled due to refund before payout.",
          {
            settlementId: settlement.id
          },
          timestamp
        );
        return {
          settlement: updatedSettlement,
          ledgerEntries: [refundEntry, feeReverseEntry]
        };
      }
      case "dispute": {
        const settlement = await this.requireOpenSettlementForAttempt(attempt.id, ["pending_payout"]);
        const updatedSettlement = await this.updateSettlementStatus(settlement, "blocked", timestamp);
        const holdEntry = await this.writeLedgerEntry({
          attemptId: attempt.id,
          intentId: intent.id,
          settlementId: settlement.id,
          type: "dispute.reserve",
          amount: settlement.netAmount,
          currency: settlement.currency,
          direction: "debit",
          createdAt: timestamp,
          metadata: {
            reason: "mock dispute reserve"
          }
        });
        await this.writeAudit(
          "attempt",
          attempt.id,
          "settlement.blocked",
          "system",
          "Settlement blocked due to dispute.",
          {
            settlementId: settlement.id
          },
          timestamp
        );
        return {
          settlement: updatedSettlement,
          ledgerEntries: [holdEntry]
        };
      }
      default:
        return {
          settlement: await this.repository.findSettlementByAttempt(attempt.id),
          ledgerEntries: []
        };
    }
  }
  async createSettlementForCapture(intent, attempt, timestamp) {
    const existing = await this.repository.findSettlementByAttempt(attempt.id);
    if (existing) {
      throw new AppError(
        "SETTLEMENT_ALREADY_EXISTS",
        `Settlement already exists for attempt ${attempt.id}.`,
        409
      );
    }
    const feeAmount = calculateMockFee(intent.money.amount);
    const settlement = {
      id: createEntityId("settlement"),
      attemptId: attempt.id,
      intentId: intent.id,
      currency: intent.money.currency,
      grossAmount: intent.money.amount,
      feeAmount,
      netAmount: intent.money.amount - feeAmount,
      status: "pending_payout",
      createdAt: timestamp,
      updatedAt: timestamp
    };
    await this.repository.saveSettlement(settlement);
    return settlement;
  }
  async updateSettlementStatus(settlement, status, timestamp) {
    const updated = {
      ...settlement,
      status,
      updatedAt: timestamp
    };
    await this.repository.saveSettlement(updated);
    return updated;
  }
  async writeLedgerEntry(entry) {
    const completeEntry = {
      id: createEntityId("ledger"),
      ...entry
    };
    await this.repository.saveLedgerEntry(completeEntry);
    return completeEntry;
  }
  computeOutstandingBalance(entries) {
    return entries.reduce((sum, entry) => {
      const signed = entry.direction === "credit" ? entry.amount : -entry.amount;
      return sum + signed;
    }, 0);
  }
  createProviderEvent(attempt, intentId, type, source, signatureVerified, receivedAt, payload) {
    return {
      id: createEntityId("event"),
      attemptId: attempt.id,
      intentId,
      provider: attempt.provider,
      type,
      source,
      signatureVerified,
      payload,
      receivedAt
    };
  }
  actorFromSource(source) {
    if (source === "webhook") {
      return "provider";
    }
    if (source === "api") {
      return "system";
    }
    return "user";
  }
  extractProviderEventId(payload) {
    const externalId = payload.id ?? payload.eventId;
    return typeof externalId === "string" ? externalId : void 0;
  }
  async findProviderEventByExternalId(attemptId, externalId) {
    const events = await this.repository.listEventsByAttempt(attemptId);
    return events.find((event) => {
      const eventId = this.extractProviderEventId(event.payload);
      return eventId === externalId;
    });
  }
  createIdempotencyRecord(scope, key, resourceType, resourceId, createdAt) {
    return {
      id: createEntityId("idemrec"),
      scope,
      key,
      resourceType,
      resourceId,
      createdAt
    };
  }
  async replayByIdempotency(scope, key, resourceType) {
    const record = await this.repository.findIdempotency(scope, key);
    if (!record) {
      return void 0;
    }
    if (record.resourceType !== resourceType) {
      throw new AppError(
        "IDEMPOTENCY_SCOPE_COLLISION",
        `Idempotency record for ${scope} resolved to ${record.resourceType}, expected ${resourceType}.`,
        409
      );
    }
    if (resourceType === "intent") {
      return await this.requireIntent(record.resourceId);
    }
    return await this.requireAttempt(record.resourceId);
  }
  async writeAudit(entityType, entityId, action, actor, message, metadata, createdAt) {
    await this.repository.saveAuditLog({
      id: createEntityId("audit"),
      entityType,
      entityId,
      action,
      actor,
      message,
      metadata,
      createdAt
    });
  }
  async requireIntent(intentId) {
    const intent = await this.repository.getIntent(intentId);
    if (!intent) {
      throw new AppError("INTENT_NOT_FOUND", `Donation intent ${intentId} was not found.`, 404);
    }
    return intent;
  }
  async requireAttempt(attemptId) {
    const attempt = await this.repository.getAttempt(attemptId);
    if (!attempt) {
      throw new AppError("ATTEMPT_NOT_FOUND", `Payment attempt ${attemptId} was not found.`, 404);
    }
    return attempt;
  }
  async requireSettlement(settlementId) {
    const settlement = await this.repository.getSettlement(settlementId);
    if (!settlement) {
      throw new AppError("SETTLEMENT_NOT_FOUND", `Settlement ${settlementId} was not found.`, 404);
    }
    return settlement;
  }
  async requireOpenSettlementForAttempt(attemptId, allowedStatuses) {
    const settlement = await this.repository.findSettlementByAttempt(attemptId);
    if (!settlement) {
      throw new AppError(
        "SETTLEMENT_NOT_FOUND",
        `Settlement for attempt ${attemptId} was not found.`,
        404
      );
    }
    if (!allowedStatuses.includes(settlement.status)) {
      throw new AppError(
        "SETTLEMENT_STATE_CONFLICT",
        `Settlement ${settlement.id} is ${settlement.status}, expected ${allowedStatuses.join(", ")}.`,
        409
      );
    }
    return settlement;
  }
  assertIntentAllowsCheckout(status) {
    if (status === "succeeded" || status === "refunded" || status === "disputed") {
      throw new AppError(
        "INTENT_TERMINAL",
        `Cannot create a new checkout from a ${status} intent.`,
        409
      );
    }
  }
};

// src/lib/repositories/payment-lab-repository-memory.ts
var InMemoryPaymentLabRepository = class {
  intents = /* @__PURE__ */ new Map();
  attempts = /* @__PURE__ */ new Map();
  providerEvents = /* @__PURE__ */ new Map();
  auditLogs = /* @__PURE__ */ new Map();
  idempotency = /* @__PURE__ */ new Map();
  settlements = /* @__PURE__ */ new Map();
  ledgerEntries = /* @__PURE__ */ new Map();
  async getSnapshot() {
    return toSortedSnapshot({
      intents: Array.from(this.intents.values()),
      attempts: Array.from(this.attempts.values()),
      providerEvents: Array.from(this.providerEvents.values()),
      auditLogs: Array.from(this.auditLogs.values()),
      idempotencyRecords: Array.from(this.idempotency.values()),
      settlements: Array.from(this.settlements.values()),
      ledgerEntries: Array.from(this.ledgerEntries.values())
    });
  }
  async reset() {
    this.intents.clear();
    this.attempts.clear();
    this.providerEvents.clear();
    this.auditLogs.clear();
    this.idempotency.clear();
    this.settlements.clear();
    this.ledgerEntries.clear();
  }
  async getIntent(id) {
    return this.intents.get(id);
  }
  async saveIntent(intent) {
    this.intents.set(intent.id, intent);
    return intent;
  }
  async getAttempt(id) {
    return this.attempts.get(id);
  }
  async findAttemptByProviderPaymentId(provider, providerPaymentId) {
    return Array.from(this.attempts.values()).find((attempt) => attempt.provider === provider && attempt.providerPaymentId === providerPaymentId);
  }
  async saveAttempt(attempt) {
    this.attempts.set(attempt.id, attempt);
    return attempt;
  }
  async saveProviderEvent(event) {
    this.providerEvents.set(event.id, event);
    return event;
  }
  async saveAuditLog(log) {
    this.auditLogs.set(log.id, log);
    return log;
  }
  async saveIdempotency(record) {
    this.idempotency.set(this.toIdempotencyMapKey(record.scope, record.key), record);
    return record;
  }
  async findIdempotency(scope, key) {
    return this.idempotency.get(this.toIdempotencyMapKey(scope, key));
  }
  async getSettlement(id) {
    return this.settlements.get(id);
  }
  async saveSettlement(settlement) {
    this.settlements.set(settlement.id, settlement);
    return settlement;
  }
  async findSettlementByAttempt(attemptId) {
    return Array.from(this.settlements.values()).find((settlement) => settlement.attemptId === attemptId);
  }
  async listSettlementsByAttempt(attemptId) {
    return Array.from(this.settlements.values()).filter((settlement) => settlement.attemptId === attemptId).sort((left, right) => right.createdAt.localeCompare(left.createdAt));
  }
  async saveLedgerEntry(entry) {
    this.ledgerEntries.set(entry.id, entry);
    return entry;
  }
  async listLedgerEntriesByAttempt(attemptId) {
    return Array.from(this.ledgerEntries.values()).filter((entry) => entry.attemptId === attemptId).sort((left, right) => right.createdAt.localeCompare(left.createdAt));
  }
  async listEventsByAttempt(attemptId) {
    return Array.from(this.providerEvents.values()).filter((event) => event.attemptId === attemptId).sort((left, right) => right.receivedAt.localeCompare(left.receivedAt));
  }
  async listAuditLogsForAttempt(attemptId, intentId) {
    return Array.from(this.auditLogs.values()).filter((log) => {
      if (log.entityType === "attempt" && log.entityId === attemptId) {
        return true;
      }
      if (log.entityType === "intent" && log.entityId === intentId) {
        return true;
      }
      if (log.entityType === "provider_event") {
        return log.metadata?.attemptId === attemptId;
      }
      return false;
    }).sort((left, right) => right.createdAt.localeCompare(left.createdAt));
  }
  toIdempotencyMapKey(scope, key) {
    return `${scope}:${key}`;
  }
};
var globalRepository = globalThis;
function getMemoryPaymentLabRepository() {
  if (!globalRepository.__PAYMENT_LAB_MEMORY_REPOSITORY__) {
    globalRepository.__PAYMENT_LAB_MEMORY_REPOSITORY__ = new InMemoryPaymentLabRepository();
  }
  return globalRepository.__PAYMENT_LAB_MEMORY_REPOSITORY__;
}

// src/lib/repositories/payment-lab-repository-turso.ts
import { createClient } from "@libsql/client/web";
function valueAsString(value) {
  return typeof value === "string" ? value : value == null ? void 0 : String(value);
}
function valueAsNumber(value) {
  return typeof value === "number" ? value : Number(value ?? 0);
}
function valueAsBoolean(value) {
  if (typeof value === "boolean") {
    return value;
  }
  if (typeof value === "number") {
    return value !== 0;
  }
  return value === "1" || value === "true";
}
function valueAsJson(value) {
  if (value == null) {
    return void 0;
  }
  if (typeof value === "string") {
    return JSON.parse(value);
  }
  return value;
}
function parseIntent(row) {
  const donor = valueAsJson(row.donor) ?? {};
  return {
    id: valueAsString(row.id),
    idempotencyKey: valueAsString(row.idempotency_key),
    itemName: valueAsString(row.item_name),
    region: valueAsString(row.region),
    money: {
      amount: valueAsNumber(row.amount),
      currency: valueAsString(row.currency)
    },
    donor: {
      name: valueAsString(donor.name),
      email: valueAsString(donor.email),
      note: valueAsString(donor.note)
    },
    status: valueAsString(row.status),
    activeAttemptId: valueAsString(row.active_attempt_id),
    createdAt: valueAsString(row.created_at),
    updatedAt: valueAsString(row.updated_at)
  };
}
function parseAttempt(row) {
  return {
    id: valueAsString(row.id),
    intentId: valueAsString(row.intent_id),
    provider: valueAsString(row.provider),
    providerPaymentId: valueAsString(row.provider_payment_id),
    status: valueAsString(row.status),
    checkoutUrl: valueAsString(row.checkout_url),
    createdAt: valueAsString(row.created_at),
    updatedAt: valueAsString(row.updated_at),
    lastEventId: valueAsString(row.last_event_id)
  };
}
function parseProviderEvent(row) {
  return {
    id: valueAsString(row.id),
    attemptId: valueAsString(row.attempt_id),
    intentId: valueAsString(row.intent_id),
    provider: valueAsString(row.provider),
    type: valueAsString(row.type),
    source: valueAsString(row.source),
    signatureVerified: valueAsBoolean(row.signature_verified),
    payload: valueAsJson(row.payload) ?? {},
    receivedAt: valueAsString(row.received_at)
  };
}
function parseAuditLog(row) {
  return {
    id: valueAsString(row.id),
    entityType: valueAsString(row.entity_type),
    entityId: valueAsString(row.entity_id),
    action: valueAsString(row.action),
    actor: valueAsString(row.actor),
    message: valueAsString(row.message),
    metadata: valueAsJson(row.metadata),
    createdAt: valueAsString(row.created_at)
  };
}
function parseIdempotency(row) {
  return {
    id: valueAsString(row.id),
    scope: valueAsString(row.scope),
    key: valueAsString(row.key),
    resourceType: valueAsString(row.resource_type),
    resourceId: valueAsString(row.resource_id),
    createdAt: valueAsString(row.created_at)
  };
}
function parseSettlement(row) {
  return {
    id: valueAsString(row.id),
    attemptId: valueAsString(row.attempt_id),
    intentId: valueAsString(row.intent_id),
    currency: valueAsString(row.currency),
    grossAmount: valueAsNumber(row.gross_amount),
    feeAmount: valueAsNumber(row.fee_amount),
    netAmount: valueAsNumber(row.net_amount),
    status: valueAsString(row.status),
    payoutReference: valueAsString(row.payout_reference),
    createdAt: valueAsString(row.created_at),
    updatedAt: valueAsString(row.updated_at),
    paidOutAt: valueAsString(row.paid_out_at)
  };
}
function parseLedgerEntry(row) {
  return {
    id: valueAsString(row.id),
    attemptId: valueAsString(row.attempt_id),
    intentId: valueAsString(row.intent_id),
    settlementId: valueAsString(row.settlement_id),
    type: valueAsString(row.type),
    amount: valueAsNumber(row.amount),
    currency: valueAsString(row.currency),
    direction: valueAsString(row.direction),
    createdAt: valueAsString(row.created_at),
    metadata: valueAsJson(row.metadata)
  };
}
var TursoPaymentLabRepository = class {
  constructor(db) {
    this.db = db;
    this.ready = this.initialize();
  }
  ready;
  async getSnapshot() {
    const [intents, attempts, providerEvents, auditLogs, idempotencyRecords, settlements, ledgerEntries] = await Promise.all([
      this.queryRows("SELECT * FROM donation_intents"),
      this.queryRows("SELECT * FROM payment_attempts"),
      this.queryRows("SELECT * FROM provider_events"),
      this.queryRows("SELECT * FROM audit_logs"),
      this.queryRows("SELECT * FROM idempotency_records"),
      this.queryRows("SELECT * FROM settlement_records"),
      this.queryRows("SELECT * FROM ledger_entries")
    ]);
    return toSortedSnapshot({
      intents: intents.map(parseIntent),
      attempts: attempts.map(parseAttempt),
      providerEvents: providerEvents.map(parseProviderEvent),
      auditLogs: auditLogs.map(parseAuditLog),
      idempotencyRecords: idempotencyRecords.map(parseIdempotency),
      settlements: settlements.map(parseSettlement),
      ledgerEntries: ledgerEntries.map(parseLedgerEntry)
    });
  }
  async reset() {
    await this.executeMany([
      "DELETE FROM ledger_entries",
      "DELETE FROM settlement_records",
      "DELETE FROM idempotency_records",
      "DELETE FROM audit_logs",
      "DELETE FROM provider_events",
      "DELETE FROM payment_attempts",
      "DELETE FROM donation_intents"
    ]);
  }
  async getIntent(id) {
    const rows = await this.queryRows("SELECT * FROM donation_intents WHERE id = ? LIMIT 1", [id]);
    return rows[0] ? parseIntent(rows[0]) : void 0;
  }
  async saveIntent(intent) {
    await this.execute(
      `INSERT INTO donation_intents (
         id, idempotency_key, item_name, region, amount, currency, donor, status, active_attempt_id, created_at, updated_at
       ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
       ON CONFLICT(id) DO UPDATE SET
         idempotency_key = excluded.idempotency_key,
         item_name = excluded.item_name,
         region = excluded.region,
         amount = excluded.amount,
         currency = excluded.currency,
         donor = excluded.donor,
         status = excluded.status,
         active_attempt_id = excluded.active_attempt_id,
         updated_at = excluded.updated_at`,
      [
        intent.id,
        intent.idempotencyKey,
        intent.itemName,
        intent.region,
        intent.money.amount,
        intent.money.currency,
        JSON.stringify(intent.donor),
        intent.status,
        intent.activeAttemptId ?? null,
        intent.createdAt,
        intent.updatedAt
      ]
    );
    return intent;
  }
  async getAttempt(id) {
    const rows = await this.queryRows("SELECT * FROM payment_attempts WHERE id = ? LIMIT 1", [id]);
    return rows[0] ? parseAttempt(rows[0]) : void 0;
  }
  async findAttemptByProviderPaymentId(provider, providerPaymentId) {
    const rows = await this.queryRows(
      "SELECT * FROM payment_attempts WHERE provider = ? AND provider_payment_id = ? LIMIT 1",
      [provider, providerPaymentId]
    );
    return rows[0] ? parseAttempt(rows[0]) : void 0;
  }
  async saveAttempt(attempt) {
    await this.execute(
      `INSERT INTO payment_attempts (
         id, intent_id, provider, provider_payment_id, status, checkout_url, created_at, updated_at, last_event_id
       ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
       ON CONFLICT(id) DO UPDATE SET
         intent_id = excluded.intent_id,
         provider = excluded.provider,
         provider_payment_id = excluded.provider_payment_id,
         status = excluded.status,
         checkout_url = excluded.checkout_url,
         updated_at = excluded.updated_at,
         last_event_id = excluded.last_event_id`,
      [
        attempt.id,
        attempt.intentId,
        attempt.provider,
        attempt.providerPaymentId,
        attempt.status,
        attempt.checkoutUrl,
        attempt.createdAt,
        attempt.updatedAt,
        attempt.lastEventId ?? null
      ]
    );
    return attempt;
  }
  async saveProviderEvent(event) {
    await this.execute(
      `INSERT INTO provider_events (
         id, attempt_id, intent_id, provider, type, source, signature_verified, payload, received_at
       ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
       ON CONFLICT(id) DO UPDATE SET
         signature_verified = excluded.signature_verified,
         payload = excluded.payload,
         received_at = excluded.received_at`,
      [
        event.id,
        event.attemptId,
        event.intentId,
        event.provider,
        event.type,
        event.source,
        event.signatureVerified ? 1 : 0,
        JSON.stringify(event.payload),
        event.receivedAt
      ]
    );
    return event;
  }
  async saveAuditLog(log) {
    await this.execute(
      `INSERT INTO audit_logs (
         id, entity_type, entity_id, action, actor, message, metadata, created_at
       ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
       ON CONFLICT(id) DO UPDATE SET
         message = excluded.message,
         metadata = excluded.metadata,
         created_at = excluded.created_at`,
      [
        log.id,
        log.entityType,
        log.entityId,
        log.action,
        log.actor,
        log.message,
        log.metadata ? JSON.stringify(log.metadata) : null,
        log.createdAt
      ]
    );
    return log;
  }
  async saveIdempotency(record) {
    await this.execute(
      `INSERT INTO idempotency_records (
         id, scope, key, resource_type, resource_id, created_at
       ) VALUES (?, ?, ?, ?, ?, ?)
       ON CONFLICT(scope, key) DO UPDATE SET
         resource_type = excluded.resource_type,
         resource_id = excluded.resource_id`,
      [record.id, record.scope, record.key, record.resourceType, record.resourceId, record.createdAt]
    );
    return record;
  }
  async findIdempotency(scope, key) {
    const rows = await this.queryRows(
      "SELECT * FROM idempotency_records WHERE scope = ? AND key = ? LIMIT 1",
      [scope, key]
    );
    return rows[0] ? parseIdempotency(rows[0]) : void 0;
  }
  async getSettlement(id) {
    const rows = await this.queryRows("SELECT * FROM settlement_records WHERE id = ? LIMIT 1", [id]);
    return rows[0] ? parseSettlement(rows[0]) : void 0;
  }
  async saveSettlement(settlement) {
    await this.execute(
      `INSERT INTO settlement_records (
         id, attempt_id, intent_id, currency, gross_amount, fee_amount, net_amount, status, payout_reference, created_at, updated_at, paid_out_at
       ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
       ON CONFLICT(id) DO UPDATE SET
         gross_amount = excluded.gross_amount,
         fee_amount = excluded.fee_amount,
         net_amount = excluded.net_amount,
         status = excluded.status,
         payout_reference = excluded.payout_reference,
         updated_at = excluded.updated_at,
         paid_out_at = excluded.paid_out_at`,
      [
        settlement.id,
        settlement.attemptId,
        settlement.intentId,
        settlement.currency,
        settlement.grossAmount,
        settlement.feeAmount,
        settlement.netAmount,
        settlement.status,
        settlement.payoutReference ?? null,
        settlement.createdAt,
        settlement.updatedAt,
        settlement.paidOutAt ?? null
      ]
    );
    return settlement;
  }
  async findSettlementByAttempt(attemptId) {
    const rows = await this.queryRows(
      "SELECT * FROM settlement_records WHERE attempt_id = ? ORDER BY created_at DESC LIMIT 1",
      [attemptId]
    );
    return rows[0] ? parseSettlement(rows[0]) : void 0;
  }
  async listSettlementsByAttempt(attemptId) {
    const rows = await this.queryRows(
      "SELECT * FROM settlement_records WHERE attempt_id = ? ORDER BY created_at DESC",
      [attemptId]
    );
    return rows.map(parseSettlement);
  }
  async saveLedgerEntry(entry) {
    await this.execute(
      `INSERT INTO ledger_entries (
         id, attempt_id, intent_id, settlement_id, type, amount, currency, direction, created_at, metadata
       ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
       ON CONFLICT(id) DO UPDATE SET
         metadata = excluded.metadata`,
      [
        entry.id,
        entry.attemptId,
        entry.intentId,
        entry.settlementId ?? null,
        entry.type,
        entry.amount,
        entry.currency,
        entry.direction,
        entry.createdAt,
        entry.metadata ? JSON.stringify(entry.metadata) : null
      ]
    );
    return entry;
  }
  async listLedgerEntriesByAttempt(attemptId) {
    const rows = await this.queryRows(
      "SELECT * FROM ledger_entries WHERE attempt_id = ? ORDER BY created_at DESC",
      [attemptId]
    );
    return rows.map(parseLedgerEntry);
  }
  async listEventsByAttempt(attemptId) {
    const rows = await this.queryRows(
      "SELECT * FROM provider_events WHERE attempt_id = ? ORDER BY received_at DESC",
      [attemptId]
    );
    return rows.map(parseProviderEvent);
  }
  async listAuditLogsForAttempt(attemptId, intentId) {
    const rows = await this.queryRows("SELECT * FROM audit_logs ORDER BY created_at DESC");
    return rows.map(parseAuditLog).filter((log) => {
      if (log.entityType === "attempt" && log.entityId === attemptId) {
        return true;
      }
      if (log.entityType === "intent" && log.entityId === intentId) {
        return true;
      }
      if (log.entityType === "provider_event") {
        return log.metadata?.attemptId === attemptId;
      }
      return false;
    });
  }
  async initialize() {
    await this.db.execute("PRAGMA foreign_keys = ON");
  }
  async queryRows(sql, args = []) {
    await this.ready;
    const result = await this.db.execute({ sql, args });
    return result.rows;
  }
  async execute(sql, args = []) {
    await this.ready;
    await this.db.execute({ sql, args });
  }
  async executeMany(statements) {
    await this.ready;
    await this.db.batch(
      statements.map((sql) => ({ sql })),
      "write"
    );
  }
};
var globalRepository2 = globalThis;
function getTursoPaymentLabRepository(databaseUrl, authToken) {
  if (!globalRepository2.__PAYMENT_LAB_TURSO_REPOSITORY__) {
    globalRepository2.__PAYMENT_LAB_TURSO_REPOSITORY__ = new TursoPaymentLabRepository(
      createClient({
        url: databaseUrl,
        authToken
      })
    );
  }
  return globalRepository2.__PAYMENT_LAB_TURSO_REPOSITORY__;
}

// src/lib/repositories/index.ts
function getPaymentLabRepository(env) {
  if (getStorageBackend(env) === "turso") {
    const databaseUrl = env.TURSO_DATABASE_URL?.trim();
    const authToken = env.TURSO_AUTH_TOKEN?.trim();
    if (!databaseUrl || !authToken) {
      throw new Error("TURSO_DATABASE_URL and TURSO_AUTH_TOKEN are required when PAYMENT_STORAGE=turso.");
    }
    return getTursoPaymentLabRepository(databaseUrl, authToken);
  }
  return getMemoryPaymentLabRepository();
}

// src/index.ts
var app = new Hono();
var createIntentSchema = z.object({
  amount: z.coerce.number().int().positive().max(1e9),
  currency: z.string().trim().length(3),
  customerEmail: z.string().email(),
  customerName: z.string().trim().min(1).max(80),
  itemName: z.string().trim().min(1).max(120),
  note: z.string().trim().max(400).optional(),
  idempotencyKey: z.string().trim().max(120).optional(),
  region: z.enum(["domestic", "international"])
});
var checkoutSchema = z.object({
  idempotencyKey: z.string().trim().max(120).optional()
});
var paypalOrderSchema = z.object({
  idempotencyKey: z.string().trim().max(120).optional()
});
var paypalCaptureSchema = z.object({
  requestId: z.string().trim().max(120).optional()
});
var mockActionSchema = z.enum(["authorize", "capture", "fail", "refund", "dispute"]);
var webhookSchema = z.object({
  attemptId: z.string().trim().min(1),
  type: z.enum([
    "payment.authorized",
    "payment.captured",
    "payment.failed",
    "payment.refunded",
    "payment.disputed"
  ])
});
function createPaymentLab(c) {
  return new PaymentLabService(getPaymentLabRepository(c.env), getPublicBaseUrl(c.env));
}
function invalidRequest(c, error) {
  return c.json(
    {
      ok: false,
      error: "INVALID_REQUEST",
      details: error.flatten()
    },
    400
  );
}
function respondWithAppError(c, error) {
  const appError = asAppError(error);
  return c.json(
    {
      ok: false,
      error: appError.code,
      message: appError.message,
      details: appError.details
    },
    appError.status
  );
}
app.get("/", async (c) => {
  try {
    const lab = createPaymentLab(c);
    return c.html(
      renderHomePage({
        appName: getAppName(c.env),
        paymentMode: getPaymentMode(c.env),
        storage: getStorageBackend(c.env),
        snapshot: await lab.getSnapshot(),
        baseUrl: getPublicBaseUrl(c.env)
      })
    );
  } catch (error) {
    return respondWithAppError(c, error);
  }
});
app.get("/demo/checkout/:attemptId", async (c) => {
  const lab = createPaymentLab(c);
  try {
    const detail = await lab.getAttempt(c.req.param("attemptId"));
    return c.html(renderCheckoutPage({ attemptId: c.req.param("attemptId"), detail }));
  } catch (error) {
    return respondWithAppError(c, error);
  }
});
app.get("/paypal/return", (c) => {
  const attemptId = c.req.query("attemptId")?.trim() || "";
  const token = c.req.query("token")?.trim() || "";
  return c.html(`<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>PayPal Return</title>
    <style>
      body { font-family: ui-sans-serif, system-ui, sans-serif; margin: 0; background: #f5f1e8; color: #1e1b16; }
      main { max-width: 760px; margin: 0 auto; padding: 40px 20px 80px; }
      .card { background: #fffaf2; border: 1px solid #d9ccb4; border-radius: 20px; padding: 24px; box-shadow: 0 16px 36px rgba(0,0,0,0.06); }
      h1 { margin: 0 0 12px; font-size: 36px; }
      p { line-height: 1.6; color: #5c554d; }
      pre { background: #191610; color: #f7f1e7; border-radius: 16px; padding: 16px; overflow: auto; min-height: 160px; }
      button { border: 0; border-radius: 14px; padding: 12px 16px; background: #0f5c52; color: white; cursor: pointer; font: inherit; }
    </style>
  </head>
  <body>
    <main>
      <div class="card">
        <h1>PayPal approval returned</h1>
        <p>Attempt: <code>${attemptId || "missing"}</code></p>
        <p>Order token: <code>${token || "missing"}</code></p>
        <button id="capture">Capture order</button>
        <pre id="output">Waiting for capture...</pre>
      </div>
    </main>
    <script>
      const attemptId = ${JSON.stringify(attemptId)};
      const output = document.getElementById("output");
      const button = document.getElementById("capture");

      async function capture() {
        if (!attemptId) {
          output.textContent = "attemptId is missing from the return URL.";
          return;
        }

        output.textContent = "Capturing PayPal order...";

        try {
          const response = await fetch("/api/paypal/attempts/" + attemptId + "/capture", {
            method: "POST",
            headers: { "content-type": "application/json" },
            body: "{}"
          });
          const payload = await response.json();
          output.textContent = JSON.stringify(payload, null, 2);
        } catch (error) {
          output.textContent = String(error);
        }
      }

      button.addEventListener("click", capture);
      capture();
    </script>
  </body>
</html>`);
});
app.get("/paypal/cancel", (c) => {
  const attemptId = c.req.query("attemptId")?.trim() || "";
  return c.html(`<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>PayPal Cancel</title>
    <style>
      body { font-family: ui-sans-serif, system-ui, sans-serif; margin: 0; background: #f5f1e8; color: #1e1b16; }
      main { max-width: 760px; margin: 0 auto; padding: 40px 20px 80px; }
      .card { background: #fffaf2; border: 1px solid #d9ccb4; border-radius: 20px; padding: 24px; }
      h1 { margin: 0 0 12px; font-size: 36px; }
      p { line-height: 1.6; color: #5c554d; }
    </style>
  </head>
  <body>
    <main>
      <div class="card">
        <h1>PayPal checkout canceled</h1>
        <p>Attempt: <code>${attemptId || "missing"}</code></p>
        <p>The order was not captured. You can reopen checkout from the API if you want to try again.</p>
      </div>
    </main>
  </body>
</html>`);
});
app.get("/api/health", (c) => {
  return c.json({
    ok: true,
    service: getAppName(c.env),
    mode: getPaymentMode(c.env),
    storage: getStorageBackend(c.env),
    now: (/* @__PURE__ */ new Date()).toISOString()
  });
});
app.get("/api/lab/snapshot", async (c) => {
  const lab = createPaymentLab(c);
  return c.json({
    ok: true,
    snapshot: await lab.getSnapshot()
  });
});
app.post("/api/lab/reset", async (c) => {
  const lab = createPaymentLab(c);
  await lab.reset();
  return c.json({
    ok: true,
    snapshot: await lab.getSnapshot()
  });
});
app.post("/api/lab/intents", async (c) => {
  const body = await c.req.json().catch(() => null);
  const parsed = createIntentSchema.safeParse(body);
  if (!parsed.success) {
    return invalidRequest(c, parsed.error);
  }
  try {
    const lab = createPaymentLab(c);
    const result = await lab.createIntent(parsed.data);
    return c.json(
      {
        ok: true,
        ...result,
        snapshot: await lab.getSnapshot()
      },
      result.replayed ? 200 : 201
    );
  } catch (error) {
    return respondWithAppError(c, error);
  }
});
app.get("/api/lab/intents/:intentId", async (c) => {
  const lab = createPaymentLab(c);
  try {
    return c.json({
      ok: true,
      intent: await lab.getIntent(c.req.param("intentId"))
    });
  } catch (error) {
    return respondWithAppError(c, error);
  }
});
app.post("/api/lab/intents/:intentId/checkout", async (c) => {
  const body = await c.req.json().catch(() => ({}));
  const parsed = checkoutSchema.safeParse(body);
  if (!parsed.success) {
    return invalidRequest(c, parsed.error);
  }
  try {
    const lab = createPaymentLab(c);
    const result = await lab.startCheckout(c.req.param("intentId"), parsed.data.idempotencyKey);
    return c.json(
      {
        ok: true,
        ...result,
        snapshot: await lab.getSnapshot()
      },
      result.replayed ? 200 : 201
    );
  } catch (error) {
    return respondWithAppError(c, error);
  }
});
app.post("/api/paypal/intents/:intentId/order", async (c) => {
  const body = await c.req.json().catch(() => ({}));
  const parsed = paypalOrderSchema.safeParse(body);
  if (!parsed.success) {
    return invalidRequest(c, parsed.error);
  }
  try {
    const credentials = getPayPalCredentials(c.env);
    const lab = createPaymentLab(c);
    const intent = await lab.getIntent(c.req.param("intentId"));
    const attemptId = createEntityId("attempt");
    const publicBaseUrl = getPublicBaseUrl(c.env);
    const order = await createPayPalOrder(credentials, {
      amount: intent.money.amount,
      currency: intent.money.currency,
      itemName: intent.itemName,
      intentId: intent.id,
      attemptId,
      requestId: parsed.data.idempotencyKey,
      returnUrl: `${publicBaseUrl}/paypal/return?attemptId=${attemptId}`,
      cancelUrl: `${publicBaseUrl}/paypal/cancel?attemptId=${attemptId}`
    });
    const approveUrl = getPayPalApprovalUrl(order);
    const result = await lab.startExternalCheckout({
      intentId: intent.id,
      provider: "paypal",
      attemptId,
      providerPaymentId: order.id,
      checkoutUrl: approveUrl,
      payload: {
        id: order.id,
        status: order.status,
        links: order.links,
        eventId: order.id,
        providerEventType: "PAYPAL.ORDER.CREATED"
      },
      idempotencyKey: parsed.data.idempotencyKey,
      source: "api",
      signatureVerified: true
    });
    return c.json({
      ok: true,
      ...result,
      paypal: {
        orderId: order.id,
        status: order.status,
        approveUrl,
        links: order.links
      }
    }, result.replayed ? 200 : 201);
  } catch (error) {
    return respondWithAppError(c, error);
  }
});
app.post("/api/paypal/attempts/:attemptId/capture", async (c) => {
  const body = await c.req.json().catch(() => ({}));
  const parsed = paypalCaptureSchema.safeParse(body);
  if (!parsed.success) {
    return invalidRequest(c, parsed.error);
  }
  try {
    const credentials = getPayPalCredentials(c.env);
    const lab = createPaymentLab(c);
    const detail = await lab.getAttempt(c.req.param("attemptId"));
    if (detail.attempt.provider !== "paypal") {
      return c.json({
        ok: false,
        error: "INVALID_PROVIDER",
        message: "Capture endpoint only supports PayPal attempts."
      }, 400);
    }
    const capture = await capturePayPalOrder(credentials, detail.attempt.providerPaymentId, parsed.data.requestId);
    const result = await lab.ingestProviderEvent({
      attemptId: detail.attempt.id,
      type: "payment.captured",
      source: "api",
      payload: {
        ...capture,
        providerEventType: "PAYMENT.CAPTURE.COMPLETED"
      },
      signatureVerified: true,
      providerEventId: typeof capture.id === "string" ? capture.id : void 0
    });
    return c.json({
      ok: true,
      ...result,
      paypal: capture,
      detail: await lab.getAttempt(detail.attempt.id)
    });
  } catch (error) {
    return respondWithAppError(c, error);
  }
});
app.get("/api/lab/attempts/:attemptId", async (c) => {
  const lab = createPaymentLab(c);
  try {
    return c.json({
      ok: true,
      ...await lab.getAttempt(c.req.param("attemptId"))
    });
  } catch (error) {
    return respondWithAppError(c, error);
  }
});
app.get("/api/lab/settlements/:settlementId", async (c) => {
  const lab = createPaymentLab(c);
  try {
    return c.json({
      ok: true,
      settlement: await lab.getSettlement(c.req.param("settlementId"))
    });
  } catch (error) {
    return respondWithAppError(c, error);
  }
});
app.post("/api/lab/settlements/:settlementId/actions/payout", async (c) => {
  const lab = createPaymentLab(c);
  try {
    const result = await lab.markSettlementPaidOut(c.req.param("settlementId"));
    return c.json({
      ok: true,
      ...result,
      settlementDetail: await lab.getSettlement(c.req.param("settlementId"))
    });
  } catch (error) {
    return respondWithAppError(c, error);
  }
});
app.post("/api/lab/attempts/:attemptId/actions/:action", async (c) => {
  const actionResult = mockActionSchema.safeParse(c.req.param("action"));
  if (!actionResult.success) {
    return invalidRequest(c, actionResult.error);
  }
  try {
    const lab = createPaymentLab(c);
    const result = await lab.applyAction(c.req.param("attemptId"), actionResult.data);
    return c.json({
      ok: true,
      ...result,
      detail: await lab.getAttempt(c.req.param("attemptId"))
    });
  } catch (error) {
    return respondWithAppError(c, error);
  }
});
app.post("/api/webhooks/mock", async (c) => {
  const rawBody = await c.req.text();
  const signature = c.req.header("x-mock-signature")?.trim() || "";
  const isVerified = await verifyMockWebhook(getMockWebhookSecret(c.env), rawBody, signature);
  if (!isVerified) {
    return c.json(
      {
        ok: false,
        error: "INVALID_WEBHOOK_SIGNATURE",
        message: "Mock webhook signature verification failed."
      },
      401
    );
  }
  let body;
  try {
    body = JSON.parse(rawBody);
  } catch {
    return c.json(
      {
        ok: false,
        error: "INVALID_JSON",
        message: "Webhook body must be valid JSON."
      },
      400
    );
  }
  const parsed = webhookSchema.safeParse(body);
  if (!parsed.success) {
    return invalidRequest(c, parsed.error);
  }
  try {
    const lab = createPaymentLab(c);
    const result = await lab.ingestWebhook(parsed.data);
    return c.json({
      ok: true,
      ...result,
      detail: await lab.getAttempt(parsed.data.attemptId)
    });
  } catch (error) {
    return respondWithAppError(c, error);
  }
});
app.post("/api/webhooks/paypal", async (c) => {
  const rawBody = await c.req.text();
  let body;
  try {
    body = JSON.parse(rawBody);
  } catch {
    return c.json(
      {
        ok: false,
        error: "INVALID_JSON",
        message: "Webhook body must be valid JSON."
      },
      400
    );
  }
  try {
    const credentials = getPayPalCredentials(c.env);
    const verified = await verifyPayPalWebhook(credentials, buildPayPalWebhookHeaders(c.req.raw.headers), body);
    if (!verified) {
      return c.json(
        {
          ok: false,
          error: "INVALID_WEBHOOK_SIGNATURE",
          message: "PayPal webhook signature verification failed."
        },
        401
      );
    }
    const eventType = typeof body.event_type === "string" ? body.event_type : "";
    const mappedType = mapPayPalWebhookEventToDomainType(eventType);
    if (!mappedType) {
      return c.json({
        ok: true,
        ignored: true,
        eventType,
        reason: "unsupported_event"
      }, 202);
    }
    const lab = createPaymentLab(c);
    let attemptId = extractPayPalAttemptId(body);
    if (!attemptId) {
      const orderId = extractPayPalOrderId(body);
      if (orderId) {
        attemptId = (await lab.findAttemptByProviderPaymentId("paypal", orderId).catch(() => void 0))?.id;
      }
    }
    if (!attemptId) {
      return c.json({
        ok: true,
        ignored: true,
        eventType,
        reason: "attempt_not_found"
      }, 202);
    }
    const result = await lab.ingestProviderEvent({
      attemptId,
      type: mappedType,
      source: "webhook",
      payload: body,
      signatureVerified: true,
      providerEventId: typeof body.id === "string" ? body.id : void 0
    });
    return c.json({
      ok: true,
      eventType,
      mappedType,
      attemptId,
      ...result,
      detail: await lab.getAttempt(attemptId)
    });
  } catch (error) {
    return respondWithAppError(c, error);
  }
});
var src_default = app;

// netlify/functions/app.ts
function getEnv(name) {
  const netlifyGlobal = globalThis;
  const fromNetlify = netlifyGlobal.Netlify?.env?.get(name);
  if (typeof fromNetlify === "string" && fromNetlify.length > 0) {
    return fromNetlify;
  }
  return process.env[name];
}
function buildBindings(context) {
  return {
    APP_NAME: getEnv("APP_NAME"),
    PAYMENT_MODE: getEnv("PAYMENT_MODE"),
    PAYMENT_STORAGE: getEnv("PAYMENT_STORAGE"),
    PUBLIC_BASE_URL: getEnv("PUBLIC_BASE_URL"),
    MOCK_WEBHOOK_SECRET: getEnv("MOCK_WEBHOOK_SECRET"),
    TURSO_DATABASE_URL: getEnv("TURSO_DATABASE_URL"),
    TURSO_AUTH_TOKEN: getEnv("TURSO_AUTH_TOKEN"),
    PAYPAL_ENV: getEnv("PAYPAL_ENV"),
    PAYPAL_CLIENT_ID: getEnv("PAYPAL_CLIENT_ID"),
    PAYPAL_CLIENT_SECRET: getEnv("PAYPAL_CLIENT_SECRET"),
    PAYPAL_WEBHOOK_ID: getEnv("PAYPAL_WEBHOOK_ID"),
    context
  };
}
var app_default = async (req, context) => {
  return src_default.fetch(req, buildBindings(context));
};
var config = {
  path: "/*",
  preferStatic: true
};
export {
  config,
  app_default as default
};
